import SwiftUI

struct AnonymousNote: Identifiable {
    let id = UUID()
    let content: String
    let timeAgo: String
    let likes: Int
    let color: Color
}

struct AnonymousView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    @State private var inputText: String = ""
    @State private var notes: [AnonymousNote] = [
        AnonymousNote(content: "悄悄努力，然后惊艳所有人 ✨", timeAgo: "10分钟前", likes: 23, color: .purple),
        AnonymousNote(content: "今天遇到一只特别粘人的三花小猫，治愈了整个星期天的疲惫！", timeAgo: "1小时前", likes: 88, color: .orange),
        AnonymousNote(content: "希望今天代码零 bug，顺利上线 🚀", timeAgo: "3小时前", likes: 142, color: .blue)
    ]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // 匿名发布输入栏
                HStack(spacing: 10) {
                    TextField("匿名倾诉此刻心声...".tr, text: $inputText)
                        .font(.system(size: 14, weight: appearance.systemFontWeight))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 10)
                        .background(Color(UIColor.secondarySystemFill))
                        .clipShape(Capsule())
                    
                    Button(action: postNote) {
                        Image(systemName: "paperplane.fill")
                            .font(.system(size: 15))
                            .foregroundColor(.white)
                            .frame(width: 38, height: 38)
                            .background(inputText.trimmingCharacters(in: .whitespaces).isEmpty ? Color.gray.opacity(0.4) : Color.blue)
                            .clipShape(Circle())
                    }
                    .disabled(inputText.trimmingCharacters(in: .whitespaces).isEmpty)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                
                Divider()
                
                // 树洞卡片流
                ScrollView(showsIndicators: false) {
                    LazyVStack(spacing: 14) {
                        ForEach(notes) { note in
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    HStack(spacing: 6) {
                                        Circle().fill(note.color).frame(width: 8, height: 8)
                                        Text("某位旅人".tr)
                                            .font(.system(size: 12, weight: .bold))
                                            .foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    Text(note.timeAgo.tr)
                                        .font(.system(size: 11))
                                        .foregroundColor(.secondary)
                                }
                                
                                Text(note.content)
                                    .font(.system(size: 15, weight: appearance.systemFontWeight))
                                    .foregroundColor(.primary)
                                    .lineSpacing(4)
                                
                                HStack {
                                    Spacer()
                                    HStack(spacing: 4) {
                                        Image(systemName: "heart.fill")
                                            .font(.caption)
                                            .foregroundColor(.pink)
                                        Text("\(note.likes)")
                                            .font(.caption)
                                            .foregroundColor(.secondary)
                                    }
                                }
                            }
                            .padding(16)
                            .background(Color(UIColor.secondarySystemGroupedBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.primary.opacity(0.05), lineWidth: 1))
                        }
                    }
                    .padding(16)
                }
            }
            .navigationTitle(lang.tr("app_anonymous"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.primary)
                    }
                }
            }
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
    
    private func postNote() {
        let text = inputText.trimmingCharacters(in: .whitespaces)
        guard !text.isEmpty else { return }
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        withAnimation(.spring(response: 0.3, dampingFraction: 0.8)) {
            notes.insert(AnonymousNote(content: text, timeAgo: "刚刚", likes: 1, color: .green), at: 0)
            inputText = ""
        }
    }
}
