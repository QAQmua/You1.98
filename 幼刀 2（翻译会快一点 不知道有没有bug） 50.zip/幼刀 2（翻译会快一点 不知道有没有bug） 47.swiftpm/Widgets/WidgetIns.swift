// MARK: - 8. WidgetIns (4×4 ins 发布页组件：全屏自适应版)
import SwiftUI
import PhotosUI

class InsPostWidgetManager: ObservableObject {
    static let shared = InsPostWidgetManager()
    
    private let avatarIdKey = "App_Widget_Ins_AvatarID"
    private let postImageIdKey = "App_Widget_Ins_PostImageID"
    
    private let addedKey = "App_Widget_Ins_IsAdded"
    private let pageKey = "App_Widget_Ins_PagePosition"
    private let rowKey = "App_Widget_Ins_RowPosition"
    private let isTransparentKey = "App_Widget_Ins_IsTransparent"
    private let bgColorKey = "App_Widget_Ins_BgColor"
    private let pinPreviewKey = "App_Widget_Ins_PinPreview"
    private let avatarSizeKey = "App_Widget_Ins_AvatarSize"
    
    private let hasBorderKey = "App_Widget_Ins_HasBorder"
    private let borderWidthKey = "App_Widget_Ins_BorderWidth"
    private let borderColorKey = "App_Widget_Ins_BorderColor"
    
    private let cancelTextKey = "App_Widget_Ins_CancelText"
    private let cancelSizeKey = "App_Widget_Ins_CancelSize"
    private let cancelWeightKey = "App_Widget_Ins_CancelWeight"
    private let cancelColorKey = "App_Widget_Ins_CancelColor"
    
    private let titleTextKey = "App_Widget_Ins_TitleText"
    private let titleSizeKey = "App_Widget_Ins_TitleSize"
    private let titleWeightKey = "App_Widget_Ins_TitleWeight"
    private let titleColorKey = "App_Widget_Ins_TitleColor"
    
    private let sendTextKey = "App_Widget_Ins_SendText"
    private let sendSizeKey = "App_Widget_Ins_SendSize"
    private let sendWeightKey = "App_Widget_Ins_SendWeight"
    private let sendColorKey = "App_Widget_Ins_SendColor"
    
    private let sendIconSizeKey = "App_Widget_Ins_SendIconSize"
    private let sendIconColorKey = "App_Widget_Ins_SendIconColor"
    private let sendIconOffsetXKey = "App_Widget_Ins_SendIconOffsetX"
    private let sendIconOffsetYKey = "App_Widget_Ins_SendIconOffsetY"
    
    private let authorNameKey = "App_Widget_Ins_AuthorName"
    private let authorNameSizeKey = "App_Widget_Ins_AuthorNameSize"
    private let authorNameWeightKey = "App_Widget_Ins_AuthorNameWeight"
    private let authorNameColorKey = "App_Widget_Ins_AuthorNameColor"
    
    private let subTextKey = "App_Widget_Ins_SubText"
    private let subTextSizeKey = "App_Widget_Ins_SubTextSize"
    private let subTextWeightKey = "App_Widget_Ins_SubTextWeight"
    private let subTextColorKey = "App_Widget_Ins_SubTextColor"
    
    private let contentTextKey = "App_Widget_Ins_ContentText"
    private let contentTextSizeKey = "App_Widget_Ins_ContentTextSize"
    private let contentTextWeightKey = "App_Widget_Ins_ContentTextWeight"
    private let contentTextColorKey = "App_Widget_Ins_ContentTextColor"
    
    @Published var avatarImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: avatarIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: avatarImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.avatarIdKey)
            }
        }
    }
    
    @Published var postImageData: Data? {
        didSet {
            let oldId = UserDefaults.standard.string(forKey: postImageIdKey)
            LocalImageStore.shared.replace(oldId: oldId, with: postImageData) { newId in
                UserDefaults.standard.set(newId, forKey: self.postImageIdKey)
            }
        }
    }
    
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: addedKey) } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: pageKey) } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: rowKey) } }
    @Published var isTransparentBackground: Bool { didSet { UserDefaults.standard.set(isTransparentBackground, forKey: isTransparentKey) } }
    @Published var backgroundColorHex: String { didSet { UserDefaults.standard.set(backgroundColorHex, forKey: bgColorKey) } }
    @Published var isPinPreviewToTop: Bool { didSet { UserDefaults.standard.set(isPinPreviewToTop, forKey: pinPreviewKey) } }
    @Published var avatarSize: Double { didSet { UserDefaults.standard.set(avatarSize, forKey: avatarSizeKey) } }
    
    @Published var hasBorder: Bool { didSet { UserDefaults.standard.set(hasBorder, forKey: hasBorderKey) } }
    @Published var borderWidth: Double { didSet { UserDefaults.standard.set(borderWidth, forKey: borderWidthKey) } }
    @Published var borderColorHex: String { didSet { UserDefaults.standard.set(borderColorHex, forKey: borderColorKey) } }
    
    @Published var headerCancelText: String {
        didSet {
            UserDefaults.standard.set(headerCancelText, forKey: cancelTextKey)
            AutoTranslationManager.shared.prewarm(text: headerCancelText)
        }
    }
    @Published var headerCancelSize: Double { didSet { UserDefaults.standard.set(headerCancelSize, forKey: cancelSizeKey) } }
    @Published var headerCancelWeightName: String { didSet { UserDefaults.standard.set(headerCancelWeightName, forKey: cancelWeightKey) } }
    @Published var headerCancelColorHex: String { didSet { UserDefaults.standard.set(headerCancelColorHex, forKey: cancelColorKey) } }
    
    @Published var headerTitle: String {
        didSet {
            UserDefaults.standard.set(headerTitle, forKey: titleTextKey)
            AutoTranslationManager.shared.prewarm(text: headerTitle)
        }
    }
    @Published var headerTitleSize: Double { didSet { UserDefaults.standard.set(headerTitleSize, forKey: titleSizeKey) } }
    @Published var headerTitleWeightName: String { didSet { UserDefaults.standard.set(headerTitleWeightName, forKey: titleWeightKey) } }
    @Published var headerTitleColorHex: String { didSet { UserDefaults.standard.set(headerTitleColorHex, forKey: titleColorKey) } }
    
    @Published var headerSendText: String {
        didSet {
            UserDefaults.standard.set(headerSendText, forKey: sendTextKey)
            AutoTranslationManager.shared.prewarm(text: headerSendText)
        }
    }
    @Published var headerSendSize: Double { didSet { UserDefaults.standard.set(headerSendSize, forKey: sendSizeKey) } }
    @Published var headerSendWeightName: String { didSet { UserDefaults.standard.set(headerSendWeightName, forKey: sendWeightKey) } }
    @Published var headerSendColorHex: String { didSet { UserDefaults.standard.set(headerSendColorHex, forKey: sendColorKey) } }
    
    @Published var sendIconSize: Double { didSet { UserDefaults.standard.set(sendIconSize, forKey: sendIconSizeKey) } }
    @Published var sendIconColorHex: String { didSet { UserDefaults.standard.set(sendIconColorHex, forKey: sendIconColorKey) } }
    @Published var sendIconOffsetX: Double { didSet { UserDefaults.standard.set(sendIconOffsetX, forKey: sendIconOffsetXKey) } }
    @Published var sendIconOffsetY: Double { didSet { UserDefaults.standard.set(sendIconOffsetY, forKey: sendIconOffsetYKey) } }
    
    @Published var authorName: String {
        didSet {
            UserDefaults.standard.set(authorName, forKey: authorNameKey)
            AutoTranslationManager.shared.prewarm(text: authorName)
        }
    }
    @Published var authorNameSize: Double { didSet { UserDefaults.standard.set(authorNameSize, forKey: authorNameSizeKey) } }
    @Published var authorNameWeightName: String { didSet { UserDefaults.standard.set(authorNameWeightName, forKey: authorNameWeightKey) } }
    @Published var authorNameColorHex: String { didSet { UserDefaults.standard.set(authorNameColorHex, forKey: authorNameColorKey) } }
    
    @Published var authorSubText: String {
        didSet {
            UserDefaults.standard.set(authorSubText, forKey: subTextKey)
            AutoTranslationManager.shared.prewarm(text: authorSubText)
        }
    }
    @Published var authorSubTextSize: Double { didSet { UserDefaults.standard.set(authorSubTextSize, forKey: subTextSizeKey) } }
    @Published var authorSubTextWeightName: String { didSet { UserDefaults.standard.set(authorSubTextWeightName, forKey: subTextWeightKey) } }
    @Published var authorSubTextColorHex: String { didSet { UserDefaults.standard.set(authorSubTextColorHex, forKey: subTextColorKey) } }
    
    @Published var contentText: String {
        didSet {
            UserDefaults.standard.set(contentText, forKey: contentTextKey)
            AutoTranslationManager.shared.prewarm(text: contentText)
        }
    }
    @Published var contentTextSize: Double { didSet { UserDefaults.standard.set(contentTextSize, forKey: contentTextSizeKey) } }
    @Published var contentTextWeightName: String { didSet { UserDefaults.standard.set(contentTextWeightName, forKey: contentTextWeightKey) } }
    @Published var contentTextColorHex: String { didSet { UserDefaults.standard.set(contentTextColorHex, forKey: contentTextColorKey) } }
    
    var backgroundColor: Color { Color(hex: backgroundColorHex) }
    var borderColor: Color { Color(hex: borderColorHex) }
    var headerCancelColor: Color { Color(hex: headerCancelColorHex) }
    var headerTitleColor: Color { Color(hex: headerTitleColorHex) }
    var headerSendColor: Color { Color(hex: headerSendColorHex) }
    var sendIconColor: Color { Color(hex: sendIconColorHex) }
    var authorNameColor: Color { Color(hex: authorNameColorHex) }
    var authorSubTextColor: Color { Color(hex: authorSubTextColorHex) }
    var contentTextColor: Color { Color(hex: contentTextColorKey) }
    
    var headerCancelWeight: Font.Weight { Font.Weight.from(name: headerCancelWeightName) }
    var headerTitleWeight: Font.Weight { Font.Weight.from(name: headerTitleWeightName) }
    var headerSendWeight: Font.Weight { Font.Weight.from(name: headerSendWeightName) }
    var authorNameWeight: Font.Weight { Font.Weight.from(name: authorNameWeightName) }
    var authorSubTextWeight: Font.Weight { Font.Weight.from(name: authorSubTextWeightName) }
    var contentTextWeight: Font.Weight { Font.Weight.from(name: contentTextWeightName) }
    
    init() {
        if let savedAvatarId = UserDefaults.standard.string(forKey: avatarIdKey) {
            self.avatarImageData = LocalImageStore.shared.load(id: savedAvatarId)
        }
        if let savedPostId = UserDefaults.standard.string(forKey: postImageIdKey) {
            self.postImageData = LocalImageStore.shared.load(id: savedPostId)
        }
        
        self.isAddedToDesktop = UserDefaults.standard.bool(forKey: addedKey)
        self.widgetPage = UserDefaults.standard.integer(forKey: pageKey)
        let rawRow = UserDefaults.standard.object(forKey: rowKey) != nil ? UserDefaults.standard.integer(forKey: rowKey) : 0
        self.widgetRow = min(max(0, rawRow), 2)
        self.isTransparentBackground = UserDefaults.standard.bool(forKey: isTransparentKey)
        self.backgroundColorHex = UserDefaults.standard.string(forKey: bgColorKey) ?? "#FFFFFF"
        self.isPinPreviewToTop = UserDefaults.standard.object(forKey: pinPreviewKey) != nil ? UserDefaults.standard.bool(forKey: pinPreviewKey) : true
        self.avatarSize = UserDefaults.standard.object(forKey: avatarSizeKey) != nil ? UserDefaults.standard.double(forKey: avatarSizeKey) : 44.0
        self.hasBorder = UserDefaults.standard.bool(forKey: hasBorderKey)
        self.borderWidth = UserDefaults.standard.object(forKey: borderWidthKey) != nil ? UserDefaults.standard.double(forKey: borderWidthKey) : 1.0
        self.borderColorHex = UserDefaults.standard.string(forKey: borderColorKey) ?? "#000000"
        self.headerCancelText = UserDefaults.standard.string(forKey: cancelTextKey) ?? "取消"
        self.headerCancelSize = UserDefaults.standard.object(forKey: cancelSizeKey) != nil ? UserDefaults.standard.double(forKey: cancelSizeKey) : 14.0
        self.headerCancelWeightName = UserDefaults.standard.string(forKey: cancelWeightKey) ?? "bold"
        self.headerCancelColorHex = UserDefaults.standard.string(forKey: cancelColorKey) ?? "#8E8E93"
        self.headerTitle = UserDefaults.standard.string(forKey: titleTextKey) ?? "发布动态"
        self.headerTitleSize = UserDefaults.standard.object(forKey: titleSizeKey) != nil ? UserDefaults.standard.double(forKey: titleSizeKey) : 15.5
        self.headerTitleWeightName = UserDefaults.standard.string(forKey: titleWeightKey) ?? "bold"
        self.headerTitleColorHex = UserDefaults.standard.string(forKey: titleColorKey) ?? "#000000"
        self.headerSendText = UserDefaults.standard.string(forKey: sendTextKey) ?? "send"
        self.headerSendSize = UserDefaults.standard.object(forKey: sendSizeKey) != nil ? UserDefaults.standard.double(forKey: sendSizeKey) : 14.0
        self.headerSendWeightName = UserDefaults.standard.string(forKey: sendWeightKey) ?? "bold"
        self.headerSendColorHex = UserDefaults.standard.string(forKey: sendColorKey) ?? "#8E8E93"
        self.sendIconSize = UserDefaults.standard.object(forKey: sendIconSizeKey) != nil ? UserDefaults.standard.double(forKey: sendIconSizeKey) : 16.0
        self.sendIconColorHex = UserDefaults.standard.string(forKey: sendIconColorKey) ?? "#8E8E93"
        self.sendIconOffsetX = UserDefaults.standard.object(forKey: sendIconOffsetXKey) != nil ? UserDefaults.standard.double(forKey: sendIconOffsetXKey) : 0.0
        self.sendIconOffsetY = UserDefaults.standard.object(forKey: sendIconOffsetYKey) != nil ? UserDefaults.standard.double(forKey: sendIconOffsetYKey) : 0.0
        self.authorName = UserDefaults.standard.string(forKey: authorNameKey) ?? "幼"
        self.authorNameSize = UserDefaults.standard.object(forKey: authorNameSizeKey) != nil ? UserDefaults.standard.double(forKey: authorNameSizeKey) : 15.0
        self.authorNameWeightName = UserDefaults.standard.string(forKey: authorNameWeightKey) ?? "bold"
        self.authorNameColorHex = UserDefaults.standard.string(forKey: authorNameColorKey) ?? "#000000"
        self.authorSubText = UserDefaults.standard.string(forKey: subTextKey) ?? "o.o  M I N E ° o .°  2768176740  oO"
        self.authorSubTextSize = UserDefaults.standard.object(forKey: subTextSizeKey) != nil ? UserDefaults.standard.double(forKey: subTextSizeKey) : 10.5
        self.authorSubTextWeightName = UserDefaults.standard.string(forKey: subTextWeightKey) ?? "medium"
        self.authorSubTextColorHex = UserDefaults.standard.string(forKey: subTextColorKey) ?? "#8E8E93"
        self.contentText = UserDefaults.standard.string(forKey: contentTextKey) ?? "此刻在想什么..."
        self.contentTextSize = UserDefaults.standard.object(forKey: contentTextSizeKey) != nil ? UserDefaults.standard.double(forKey: contentTextSizeKey) : 14.0
        self.contentTextWeightName = UserDefaults.standard.string(forKey: contentTextWeightKey) ?? "medium"
        self.contentTextColorHex = UserDefaults.standard.string(forKey: contentTextColorKey) ?? "#8E8E93"
        
        AutoTranslationManager.shared.prewarm(text: headerCancelText)
        AutoTranslationManager.shared.prewarm(text: headerTitle)
        AutoTranslationManager.shared.prewarm(text: authorName)
        AutoTranslationManager.shared.prewarm(text: contentText)
    }
}

struct InsPostWidget4x4View: View {
    var avatarImageData: Data?
    var postImageData: Data?
    var avatarSize: Double = 46.0
    var hasBorder: Bool = false
    var borderWidth: Double = 1.0
    var borderColor: Color = .black
    var headerCancelText: String = "取消"
    var headerCancelSize: Double = 15.0
    var headerCancelWeight: Font.Weight = .bold
    var headerCancelColor: Color = Color(hex: "#8E8E93")
    var headerTitle: String = "发布动态"
    var headerTitleSize: Double = 16.0
    var headerTitleWeight: Font.Weight = .bold
    var headerTitleColor: Color = .primary
    var headerSendText: String = "send"
    var headerSendSize: Double = 15.0
    var headerSendWeight: Font.Weight = .bold
    var headerSendColor: Color = Color(hex: "#8E8E93")
    var sendIconSize: Double = 16.0
    var sendIconColor: Color = Color(hex: "#8E8E93")
    var sendIconOffsetX: Double = 0.0
    var sendIconOffsetY: Double = 0.0
    var authorName: String = "幼"
    var authorNameSize: Double = 15.5
    var authorNameWeight: Font.Weight = .bold
    var authorNameColor: Color = .primary
    var authorSubText: String = "o.o  M I N E ° o .°  2768176740  oO"
    var authorSubTextSize: Double = 11.0
    var authorSubTextWeight: Font.Weight = .medium
    var authorSubTextColor: Color = Color(hex: "#8E8E93")
    var contentText: String = "此刻在想什么..."
    var contentTextSize: Double = 14.0
    var contentTextWeight: Font.Weight = .medium
    var contentTextColor: Color = Color(hex: "#8E8E93")
    var isTransparent: Bool = false
    var backgroundColor: Color = .white
    var isEditing: Bool = false
    var showDashedBorder: Bool = false
    var onDelete: (() -> Void)? = nil
    var onDeletePostImage: (() -> Void)? = nil
    var onSelectPostImage: (() -> Void)? = nil
    
    init(manager: InsPostWidgetManager = .shared, isEditing: Bool = false, showDashedBorder: Bool = false, onDelete: (() -> Void)? = nil, onDeletePostImage: (() -> Void)? = nil, onSelectPostImage: (() -> Void)? = nil) {
        self.avatarImageData = manager.avatarImageData
        self.postImageData = manager.postImageData
        self.avatarSize = manager.avatarSize
        self.hasBorder = manager.hasBorder
        self.borderWidth = manager.borderWidth
        self.borderColor = manager.borderColor
        self.headerCancelText = manager.headerCancelText
        self.headerCancelSize = manager.headerCancelSize
        self.headerCancelWeight = manager.headerCancelWeight
        self.headerCancelColor = manager.headerCancelColor
        self.headerTitle = manager.headerTitle
        self.headerTitleSize = manager.headerTitleSize
        self.headerTitleWeight = manager.headerTitleWeight
        self.headerTitleColor = manager.headerTitleColor
        self.headerSendText = manager.headerSendText
        self.headerSendSize = manager.headerSendSize
        self.headerSendWeight = manager.headerSendWeight
        self.headerSendColor = manager.headerSendColor
        self.sendIconSize = manager.sendIconSize
        self.sendIconColor = manager.sendIconColor
        self.sendIconOffsetX = manager.sendIconOffsetX
        self.sendIconOffsetY = manager.sendIconOffsetY
        self.authorName = manager.authorName
        self.authorNameSize = manager.authorNameSize
        self.authorNameWeight = manager.authorNameWeight
        self.authorNameColor = manager.authorNameColor
        self.authorSubText = manager.authorSubText
        self.authorSubTextSize = manager.authorSubTextSize
        self.authorSubTextWeight = manager.authorSubTextWeight
        self.authorSubTextColor = manager.authorSubTextColor
        self.contentText = manager.contentText
        self.contentTextSize = manager.contentTextSize
        self.contentTextWeight = manager.contentTextWeight
        self.contentTextColor = manager.contentTextColor
        self.isTransparent = manager.isTransparentBackground
        self.backgroundColor = manager.backgroundColor
        self.isEditing = isEditing
        self.showDashedBorder = showDashedBorder
        self.onDelete = onDelete
        self.onDeletePostImage = onDeletePostImage
        self.onSelectPostImage = onSelectPostImage
    }
    
    @ObservedObject var translator = AutoTranslationManager.shared
    @ObservedObject var appearance = SystemAppearance.shared
    
    private func effectiveWeight(_ customWeight: Font.Weight) -> Font.Weight {
        appearance.preferWidgetFontPriority ? customWeight : appearance.systemFontWeight
    }
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            Group {
                if isTransparent { Color.clear } else { backgroundColor }
            }
            .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
            
            VStack(alignment: .leading, spacing: 0) {
                // 顶部导航栏
                ZStack {
                    HStack {
                        Text(translator.translate(headerCancelText))
                            .font(.system(size: CGFloat(headerCancelSize)))
                            .fontWeight(effectiveWeight(headerCancelWeight))
                            .foregroundColor(headerCancelColor)
                        Spacer()
                        HStack(spacing: 5) {
                            Text(translator.translate(headerSendText))
                                .font(.system(size: CGFloat(headerSendSize)))
                                .fontWeight(effectiveWeight(headerSendWeight))
                                .foregroundColor(headerSendColor)
                            InsSendPlaneIcon(size: CGFloat(sendIconSize), color: sendIconColor)
                                .offset(x: CGFloat(sendIconOffsetX), y: CGFloat(sendIconOffsetY))
                        }
                    }
                    Text(translator.translate(headerTitle))
                        .font(.system(size: CGFloat(headerTitleSize)))
                        .fontWeight(effectiveWeight(headerTitleWeight))
                        .foregroundColor(headerTitleColor)
                }
                .padding(.horizontal, 6)
                .padding(.top, 4)
                
                Spacer(minLength: 16)
                
                // 头像与作者
                HStack(spacing: 12) {
                    Group {
                        if let data = avatarImageData, let uiImage = ImageBitmapCache.shared.image(from: data) {
                            Image(uiImage: uiImage).resizable().scaledToFill()
                        } else {
                            ZStack {
                                Color(UIColor.systemGray5)
                                Image(systemName: "person.fill").font(.system(size: CGFloat(avatarSize * 0.44))).foregroundColor(.secondary)
                            }
                        }
                    }
                    .frame(width: CGFloat(avatarSize), height: CGFloat(avatarSize))
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.primary.opacity(0.06), lineWidth: 0.8))
                    
                    VStack(alignment: .leading, spacing: 3.5) {
                        Text(translator.translate(authorName))
                            .font(.system(size: CGFloat(authorNameSize)))
                            .fontWeight(effectiveWeight(authorNameWeight))
                            .foregroundColor(authorNameColor)
                        Text(translator.translate(authorSubText))
                            .font(.system(size: CGFloat(authorSubTextSize)))
                            .fontWeight(effectiveWeight(authorSubTextWeight))
                            .foregroundColor(authorSubTextColor)
                            .lineLimit(1)
                    }
                    Spacer()
                }
                .padding(.horizontal, 4)
                
                Spacer(minLength: 14)
                
                // 文案正文
                Text(translator.translate(contentText))
                    .font(.system(size: CGFloat(contentTextSize)))
                    .fontWeight(effectiveWeight(contentTextWeight))
                    .foregroundColor(contentTextColor)
                    .padding(.horizontal, 6)
                
                Spacer(minLength: 16)
                
                // 发帖附图区域
                HStack(spacing: 14) {
                    ZStack(alignment: .topTrailing) {
                        if let postData = postImageData, let postUiImg = ImageBitmapCache.shared.image(from: postData) {
                            Image(uiImage: postUiImg).resizable().scaledToFill()
                                .frame(width: 96, height: 96)
                                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                                .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(Color.primary.opacity(0.06), lineWidth: 0.8))
                            
                            Button(action: { onDeletePostImage?() }) {
                                ZStack {
                                    Circle().fill(Color.black.opacity(0.28)).frame(width: 22, height: 22)
                                    Image(systemName: "xmark").font(.system(size: 10, weight: .bold)).foregroundColor(.white)
                                }
                            }
                            .padding(6)
                        } else {
                            Button(action: { onSelectPostImage?() }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(UIColor.systemGray6).opacity(0.85)).frame(width: 96, height: 96)
                                    Image(systemName: "photo").font(.system(size: 24)).foregroundColor(contentTextColor.opacity(0.55))
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    
                    Button(action: { onSelectPostImage?() }) {
                        ZStack {
                            RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Color(UIColor.systemGray6).opacity(0.85)).frame(width: 96, height: 96)
                            Image(systemName: "plus").font(.system(size: 26, weight: .medium)).foregroundColor(contentTextColor.opacity(0.65))
                        }
                    }
                    .buttonStyle(.plain)
                    
                    Spacer()
                }
                .padding(.horizontal, 4)
                .padding(.bottom, 4)
            }
            .padding(16)
            
            Group {
                if hasBorder {
                    RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(borderColor, lineWidth: CGFloat(borderWidth))
                } else if isTransparent && showDashedBorder {
                    RoundedRectangle(cornerRadius: 26, style: .continuous).stroke(Color.secondary.opacity(0.4), style: StrokeStyle(lineWidth: 1, dash: [5, 4]))
                }
            }
            .allowsHitTesting(false)
            
            if isEditing, let onDelete = onDelete {
                Button(action: onDelete) { WidgetDeleteBadge() }
                    .padding(8).transition(.scale.combined(with: .opacity))
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct EditInsWidgetSheet: View {
    @Binding var isPresented: Bool
    @ObservedObject var widgetManager = InsPostWidgetManager.shared
    @ObservedObject var translator = AutoTranslationManager.shared
    @State private var selectedAvatarItem: PhotosPickerItem? = nil
    @State private var selectedPostItem: PhotosPickerItem? = nil
    @ObservedObject var appearance = SystemAppearance.shared
    
    private let textColors = ["#000000", "#FFFFFF", "#3C3C43", "#8E8E93", "#007AFF", "#FF2D55", "#5856D6", "#FF9500"]
    private let bgPresets = ["#FFFFFF", "#EDEDF2", "#1C1C1E", "#FDE2E4", "#E2ECE9", "#FFF1C5", "#D0E1FD", "#E8DFF5"]
    private let borderPresets = ["#000000", "#8E8E93", "#FFFFFF", "#007AFF", "#FF2D55", "#5856D6", "#E5E5EA"]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                if widgetManager.isPinPreviewToTop {
                    previewCardView.background(Color(UIColor.systemGroupedBackground))
                    Divider()
                }
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        if !widgetManager.isPinPreviewToTop {
                            previewCardView.padding(.top, 8)
                        }
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("背景与显示模式".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.isPinPreviewToTop) {
                                Label("固定顶部预览".tr, systemImage: "pin.fill").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            Divider()
                            Toggle(isOn: $widgetManager.isTransparentBackground) {
                                Label("背景透明模式".tr, systemImage: "circle.lefthalf.filled").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if !widgetManager.isTransparentBackground {
                                Divider()
                                WidgetColorPaletteRow(title: "组件背景底色".tr, selectedHex: widgetManager.backgroundColorHex, presets: bgPresets, currentColor: widgetManager.backgroundColor, onSelectHex: { widgetManager.backgroundColorHex = $0 }, onPickColor: { widgetManager.backgroundColorHex = $0.toHex() })
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16).padding(.top, widgetManager.isPinPreviewToTop ? 12 : 0)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("组件外边框描边".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            Toggle(isOn: $widgetManager.hasBorder) {
                                Label("启用外边框描边".tr, systemImage: "square.dashed").font(.system(size: 15, weight: appearance.systemFontWeight))
                            }
                            if widgetManager.hasBorder {
                                Divider()
                                VStack(alignment: .leading, spacing: 6) {
                                    HStack {
                                        Text("描边粗细".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                        Spacer()
                                        Text(String(format: "%.1f pt", widgetManager.borderWidth)).font(.caption).foregroundColor(.secondary)
                                    }
                                    Slider(value: $widgetManager.borderWidth, in: 0.1...6.0, step: 0.1)
                                }
                                Divider()
                                WidgetColorPaletteRow(title: "描边颜色".tr, selectedHex: widgetManager.borderColorHex, presets: borderPresets, currentColor: widgetManager.borderColor, onSelectHex: { widgetManager.borderColorHex = $0 }, onPickColor: { widgetManager.borderColorHex = $0.toHex() })
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("照片设置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            PhotosPicker(selection: $selectedAvatarItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换圆形头像".tr, systemImage: "person.crop.circle.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            if widgetManager.avatarImageData != nil {
                                Divider()
                                Button(role: .destructive, action: { withAnimation { widgetManager.avatarImageData = nil } }) {
                                    Label("清空已选头像".tr, systemImage: "trash").font(.system(size: 15, weight: appearance.systemFontWeight))
                                }
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("头像大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text("\(Int(widgetManager.avatarSize)) pt").font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.avatarSize, in: 28...60, step: 1)
                            }
                            Divider()
                            PhotosPicker(selection: $selectedPostItem, matching: .images, photoLibrary: .shared()) {
                                HStack {
                                    Label("更换发帖主图".tr, systemImage: "photo.badge.plus").font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.caption.weight(.semibold)).foregroundColor(.secondary)
                                }
                            }
                            .foregroundColor(.primary)
                            
                            if widgetManager.postImageData != nil {
                                Divider()
                                Button(role: .destructive, action: { withAnimation { widgetManager.postImageData = nil } }) {
                                    Label("清空已选发帖图".tr, systemImage: "trash").font(.system(size: 15, weight: appearance.systemFontWeight))
                                }
                            }
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "左上角操作文字".tr, placeholder: "如：取消".tr, text: $widgetManager.headerCancelText, size: $widgetManager.headerCancelSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerCancelWeightName, selectedHex: widgetManager.headerCancelColorHex, currentColor: widgetManager.headerCancelColor, onSelectHex: { widgetManager.headerCancelColorHex = $0 }, onPickColor: { widgetManager.headerCancelColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "顶部居中主标题".tr, placeholder: "如：发布动态".tr, text: $widgetManager.headerTitle, size: $widgetManager.headerTitleSize, minSize: 11, maxSize: 22, selectedWeightName: $widgetManager.headerTitleWeightName, selectedHex: widgetManager.headerTitleColorHex, currentColor: widgetManager.headerTitleColor, onSelectHex: { widgetManager.headerTitleColorHex = $0 }, onPickColor: { widgetManager.headerTitleColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "右上角发送文字".tr, placeholder: "如：send".tr, text: $widgetManager.headerSendText, size: $widgetManager.headerSendSize, minSize: 10, maxSize: 20, selectedWeightName: $widgetManager.headerSendWeightName, selectedHex: widgetManager.headerSendColorHex, currentColor: widgetManager.headerSendColor, onSelectHex: { widgetManager.headerSendColorHex = $0 }, onPickColor: { widgetManager.headerSendColorHex = $0.toHex() })
                        
                        VStack(alignment: .leading, spacing: 14) {
                            Text("右上角纸飞机图标设置".tr).font(.system(size: 13, weight: appearance.systemFontWeight)).foregroundColor(.secondary)
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("图标大小".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%.1f pt", widgetManager.sendIconSize)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconSize, in: 8.0...35.0, step: 0.5)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("左右横向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetX)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconOffsetX, in: -30.0...30.0, step: 0.5)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("上下纵向微调".tr).font(.system(size: 15, weight: appearance.systemFontWeight))
                                    Spacer()
                                    Text(String(format: "%+.1f pt", widgetManager.sendIconOffsetY)).font(.caption).foregroundColor(.secondary)
                                }
                                Slider(value: $widgetManager.sendIconOffsetY, in: -30.0...30.0, step: 0.5)
                            }
                            Divider()
                            WidgetColorPaletteRow(title: "图标颜色".tr, selectedHex: widgetManager.sendIconColorHex, presets: textColors, currentColor: widgetManager.sendIconColor, onSelectHex: { widgetManager.sendIconColorHex = $0 }, onPickColor: { widgetManager.sendIconColorHex = $0.toHex() })
                        }
                        .padding(16).background(Color(UIColor.secondarySystemGroupedBackground)).cornerRadius(18).padding(.horizontal, 16)
                        
                        WidgetTextSectionEditor(sectionTitle: "发布者昵称".tr, placeholder: "如：幼".tr, text: $widgetManager.authorName, size: $widgetManager.authorNameSize, minSize: 11, maxSize: 24, selectedWeightName: $widgetManager.authorNameWeightName, selectedHex: widgetManager.authorNameColorHex, currentColor: widgetManager.authorNameColor, onSelectHex: { widgetManager.authorNameColorHex = $0 }, onPickColor: { widgetManager.authorNameColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "个性签名 / ID 排版".tr, placeholder: "如：o.o M I N E...".tr, text: $widgetManager.authorSubText, size: $widgetManager.authorSubTextSize, minSize: 8, maxSize: 18, selectedWeightName: $widgetManager.authorSubTextWeightName, selectedHex: widgetManager.authorSubTextColorHex, currentColor: widgetManager.authorSubTextColor, onSelectHex: { widgetManager.authorSubTextColorHex = $0 }, onPickColor: { widgetManager.authorSubTextColorHex = $0.toHex() })
                        WidgetTextSectionEditor(sectionTitle: "发帖正文描述 / 占位词".tr, placeholder: "如：此刻在想什么...".tr, text: $widgetManager.contentText, size: $widgetManager.contentTextSize, minSize: 10, maxSize: 22, selectedWeightName: $widgetManager.contentTextWeightName, selectedHex: widgetManager.contentTextColorHex, currentColor: widgetManager.contentTextColor, onSelectHex: { widgetManager.contentTextColorHex = $0 }, onPickColor: { widgetManager.contentTextColorHex = $0.toHex() })
                    }
                    .padding(.bottom, 32)
                }
                .background(Color(UIColor.systemGroupedBackground))
            }
            .navigationTitle("定制 ins 发布页".tr)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成".tr) {
                        UIImpactFeedbackGenerator(style: .light).impactOccurred()
                        isPresented = false
                    }
                    .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .task(id: selectedAvatarItem) {
                if let data = try? await selectedAvatarItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { widgetManager.avatarImageData = data }
                }
            }
            .task(id: selectedPostItem) {
                if let data = try? await selectedPostItem?.loadTransferable(type: Data.self) {
                    withAnimation(.easeInOut(duration: 0.25)) { widgetManager.postImageData = data }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }
    
    private var previewCardView: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 26, style: .continuous).fill(Color(UIColor.secondarySystemGroupedBackground)).frame(height: 355)
            InsPostWidget4x4View(
                manager: widgetManager,
                showDashedBorder: true,
                onDeletePostImage: { withAnimation { widgetManager.postImageData = nil } }
            )
            .frame(height: 330)
            .padding(.horizontal, 16)
        }
        .padding(.horizontal, 16).padding(.top, 10).padding(.bottom, 10)
    }
}

extension WidgetRegistry {
    func registerInsWidget() {
        let mgr = InsPostWidgetManager.shared
        registerWidget(
            id: "ins",
            title: "widget_ins_title",
            subtitle: "sub_ins",
            badge: "4×4",
            manager: mgr,
            desktopView: {
                InsPostWidget4x4View(manager: mgr)
            },
            previewView: {
                InsPostWidget4x4View(manager: mgr)
                    .frame(height: 330)
                    .scaleEffect(0.68)
                    .frame(height: 235)
            },
            editSheetView: { show in
                EditInsWidgetSheet(isPresented: show)
            }
        )
    }
}
