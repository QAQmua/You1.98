import SwiftUI

struct HourlyForecast: Identifiable {
    let id = UUID()
    let time: String
    let icon: String
    let temp: String
}

struct WeatherView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    let hourlyData: [HourlyForecast] = [
        HourlyForecast(time: "现在", icon: "sun.max.fill", temp: "26°"),
        HourlyForecast(time: "15时", icon: "sun.max.fill", temp: "27°"),
        HourlyForecast(time: "16时", icon: "cloud.sun.fill", temp: "25°"),
        HourlyForecast(time: "17时", icon: "cloud.fill", temp: "23°"),
        HourlyForecast(time: "18时", icon: "cloud.moon.fill", temp: "21°"),
        HourlyForecast(time: "19时", icon: "moon.stars.fill", temp: "20°")
    ]
    
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [Color.blue.opacity(0.85), Color.cyan.opacity(0.65)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 24) {
                        // 顶部城市与气温概览
                        VStack(spacing: 4) {
                            Text("北京市".tr)
                                .font(.system(size: 28, weight: appearance.systemFontWeight))
                                .foregroundColor(.white)
                            Text("26°")
                                .font(.system(size: 72, weight: .thin))
                                .foregroundColor(.white)
                            Text("晴朗 · 最高 28° 最低 17°".tr)
                                .font(.system(size: 14, weight: appearance.systemFontWeight))
                                .foregroundColor(.white.opacity(0.9))
                        }
                        .padding(.top, 24)
                        
                        // 24小时逐小时横滑卡片
                        VStack(alignment: .leading, spacing: 12) {
                            HStack(spacing: 6) {
                                Image(systemName: "clock")
                                Text("未来逐小时预报".tr)
                            }
                            .font(.system(size: 13, weight: appearance.systemFontWeight))
                            .foregroundColor(.white.opacity(0.8))
                            
                            Divider().background(Color.white.opacity(0.2))
                            
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 20) {
                                    ForEach(hourlyData) { item in
                                        VStack(spacing: 8) {
                                            Text(item.time.tr)
                                                .font(.system(size: 13))
                                                .foregroundColor(.white)
                                            Image(systemName: item.icon)
                                                .font(.system(size: 20))
                                                .foregroundColor(.yellow)
                                            Text(item.temp)
                                                .font(.system(size: 15, weight: .semibold))
                                                .foregroundColor(.white)
                                        }
                                    }
                                }
                                .padding(.horizontal, 4)
                            }
                        }
                        .padding(16)
                        .background(.ultraThinMaterial.opacity(0.45))
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .padding(.horizontal, 16)
                        
                        // 空气质量与生活指数
                        HStack(spacing: 12) {
                            VStack(alignment: .leading, spacing: 8) {
                                Label("空气质量".tr, systemImage: "aqi.low")
                                    .font(.system(size: 12))
                                    .foregroundColor(.white.opacity(0.8))
                                Text("38 · 优".tr)
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            .padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(.ultraThinMaterial.opacity(0.45))
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                            
                            VStack(alignment: .leading, spacing: 8) {
                                Label("紫外线指数".tr, systemImage: "sun.max")
                                    .font(.system(size: 12))
                                    .foregroundColor(.white.opacity(0.8))
                                Text("3 · 中等".tr)
                                    .font(.system(size: 20, weight: .bold))
                                    .foregroundColor(.white)
                            }
                            .padding(16)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(.ultraThinMaterial.opacity(0.45))
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        }
                        .padding(.horizontal, 16)
                    }
                    .padding(.bottom, 30)
                }
            }
            .navigationTitle("")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button(action: {
                        withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                    }) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 16, weight: appearance.systemFontWeight))
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .preferredColorScheme(.dark)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
