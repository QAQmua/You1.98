// 📄 替换文件：33.swiftpm/微信/AIWeChatView.swift
import SwiftUI

// MARK: - 微信主路由
struct AIWeChatView: View {
    @Binding var show: Bool
    @AppStorage("WeChat_IsLoggedIn") private var isLoggedIn: Bool = false
    @ObservedObject var appearance = SystemAppearance.shared 
    
    var body: some View {
        Group {
            if isLoggedIn {
                WeChatMainView(show: $show, isLoggedIn: $isLoggedIn)
            } else {
                WeChatAuthRootView(show: $show, isLoggedIn: $isLoggedIn)
            }
        }
        .preferredColorScheme(appearance.colorScheme)
        // 桌面系统的全局右滑退出手势 (在任意界面向右长滑即可退出微信)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}

// MARK: - 1. 微信欢迎页面 (高仿微信冷启动)
struct WeChatAuthRootView: View {
    @Binding var show: Bool
    @Binding var isLoggedIn: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Spacer()
                
                // 顶部返回箭头(仿微信关闭按钮)
                HStack {
                    Button(action: {
                        withAnimation(.spring()) { show = false }
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 20))
                            .foregroundColor(.primary)
                            .padding()
                    }
                    Spacer()
                }
                .padding(.top, 10)
                
                Spacer()
                
                // 微信大图标
                Image(systemName: "message.fill")
                    .font(.system(size: 80))
                    .foregroundColor(Color(hex: "#07C160"))
                    .padding(.bottom, 30)
                
                Spacer()
                
                // 底部按钮组
                HStack(spacing: 16) {
                    NavigationLink(destination: WeChatLoginView(isLoggedIn: $isLoggedIn)) {
                        Text("登录".tr)
                            .font(.system(size: 16, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(UIColor.secondarySystemFill))
                            .foregroundColor(Color(hex: "#07C160"))
                            .cornerRadius(8)
                    }
                    
                    NavigationLink(destination: WeChatRegisterView(isLoggedIn: $isLoggedIn)) {
                        Text("注册".tr)
                            .font(.system(size: 16, weight: .medium))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color(hex: "#07C160"))
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 50)
            }
            .navigationBarHidden(true)
            .background(Color(UIColor.systemBackground))
        }
    }
}

// MARK: - 2. 微信真实登录页 (手机号 + 密码)
struct WeChatLoginView: View {
    @Binding var isLoggedIn: Bool
    @Environment(\.dismiss) var dismiss
    
    @State private var phoneNumber: String = ""
    @State private var isAgreed: Bool = false
    @State private var showWarning: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("微信号/QQ/邮箱登录".tr)
                .font(.system(size: 22, weight: .regular))
                .padding(.top, 40)
                .padding(.horizontal, 24)
                .padding(.bottom, 40)
            
            // 表单区
            VStack(spacing: 0) {
                HStack {
                    Text("账号".tr)
                        .frame(width: 80, alignment: .leading)
                        .font(.system(size: 16))
                    TextField("微信号/QQ号/邮箱".tr, text: $phoneNumber)
                        .font(.system(size: 16))
                        .textInputAutocapitalization(.never)
                }
                .padding(.vertical, 16)
                .overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("密码".tr)
                        .frame(width: 80, alignment: .leading)
                        .font(.system(size: 16))
                    SecureField("请填写密码".tr, text: .constant(""))
                        .font(.system(size: 16))
                }
                .padding(.vertical, 16)
                .overlay(Divider(), alignment: .bottom)
            }
            .padding(.horizontal, 24)
            
            Text("用手机号登录".tr)
                .font(.system(size: 14))
                .foregroundColor(Color(hex: "#576B95")) // 微信标准蓝色链接
                .padding(.horizontal, 24)
                .padding(.top, 16)
            
            Spacer()
            
            // 协议区
            HStack(alignment: .top, spacing: 8) {
                Button(action: { isAgreed.toggle(); showWarning = false }) {
                    Image(systemName: isAgreed ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(isAgreed ? Color(hex: "#07C160") : .gray)
                        .font(.system(size: 18))
                }
                Text("已阅读并同意《软件许可及服务协议》".tr)
                    .font(.system(size: 12))
                    .foregroundColor(.gray)
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 16)
            
            if showWarning {
                Text("请先阅读并勾选协议".tr)
                    .font(.system(size: 12))
                    .foregroundColor(.red)
                    .padding(.horizontal, 50)
                    .padding(.bottom, 10)
            }
            
            // 登录按钮 (假装登录成功)
            Button(action: {
                if isAgreed {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = true }
                } else {
                    showWarning = true
                    UINotificationFeedbackGenerator().notificationOccurred(.error)
                }
            }) {
                Text("同意并登录".tr)
                    .font(.system(size: 16, weight: .medium))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(!phoneNumber.isEmpty ? Color(hex: "#07C160") : Color(hex: "#07C160").opacity(0.4))
                    .foregroundColor(phoneNumber.isEmpty ? .white.opacity(0.6) : .white)
                    .cornerRadius(8)
            }
            .disabled(phoneNumber.isEmpty)
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.primary)
                }
            }
        }
    }
}

// MARK: - 3. 微信真实注册页 (带头像、昵称、手机号、密码)
struct WeChatRegisterView: View {
    @Binding var isLoggedIn: Bool
    @Environment(\.dismiss) var dismiss
    
    @State private var nickname: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var isAgreed: Bool = false
    @State private var showWarning: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("用手机号注册".tr)
                .font(.system(size: 22, weight: .regular))
                .padding(.top, 20)
                .padding(.horizontal, 24)
                .padding(.bottom, 30)
            
            // 头像选择区
            HStack {
                Spacer()
                ZStack {
                    RoundedRectangle(cornerRadius: 12).fill(Color(UIColor.secondarySystemFill)).frame(width: 70, height: 70)
                    Image(systemName: "camera.fill").foregroundColor(.gray).font(.system(size: 24))
                }
                Spacer()
            }
            .padding(.bottom, 30)
            
            // 真实表单
            VStack(spacing: 0) {
                HStack {
                    Text("昵称".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    TextField("例如：陈晨".tr, text: $nickname).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("国家/地区".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    Text("中国大陆 (+86)".tr).foregroundColor(Color(hex: "#07C160")).font(.system(size: 16))
                    Spacer()
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("手机号".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    TextField("请填写手机号".tr, text: $phoneNumber).keyboardType(.numberPad).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
                
                HStack {
                    Text("密码".tr).frame(width: 80, alignment: .leading).font(.system(size: 16))
                    SecureField("填写密码".tr, text: $password).font(.system(size: 16))
                }
                .padding(.vertical, 16).overlay(Divider(), alignment: .bottom)
            }
            .padding(.horizontal, 24)
            
            Spacer()
            
            HStack(alignment: .top, spacing: 8) {
                Button(action: { isAgreed.toggle(); showWarning = false }) {
                    Image(systemName: isAgreed ? "checkmark.circle.fill" : "circle")
                        .foregroundColor(isAgreed ? Color(hex: "#07C160") : .gray).font(.system(size: 18))
                }
                Text("我已阅读并同意《软件许可及服务协议》与《隐私政策》".tr)
                    .font(.system(size: 12)).foregroundColor(.gray).lineSpacing(4)
            }
            .padding(.horizontal, 24).padding(.bottom, 16)
            
            if showWarning {
                Text("请先阅读并勾选协议".tr).font(.system(size: 12)).foregroundColor(.red).padding(.horizontal, 50).padding(.bottom, 10)
            }
            
            // 跳向短信验证
            NavigationLink(destination: WeChatVerificationView(phoneNumber: phoneNumber, isLoggedIn: $isLoggedIn)) {
                Text("同意并继续".tr)
                    .font(.system(size: 16, weight: .medium))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(isFormValid ? Color(hex: "#07C160") : Color(hex: "#07C160").opacity(0.4))
                    .foregroundColor(isFormValid ? .white : .white.opacity(0.6))
                    .cornerRadius(8)
            }
            .disabled(!isFormValid)
            .simultaneousGesture(TapGesture().onEnded {
                if !isAgreed { showWarning = true; UINotificationFeedbackGenerator().notificationOccurred(.error) }
            })
            .padding(.horizontal, 24)
            .padding(.bottom, 40)
        }
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: { dismiss() }) { Image(systemName: "xmark").foregroundColor(.primary) }
            }
        }
    }
    
    private var isFormValid: Bool {
        return !phoneNumber.isEmpty && !password.isEmpty && !nickname.isEmpty
    }
}

// MARK: - 4. 验证码输入
struct WeChatVerificationView: View {
    var phoneNumber: String
    @Binding var isLoggedIn: Bool
    
    @State private var verifyCode: String = ""
    @State private var timeRemaining = 60
    @State private var timer: Timer?
    @State private var isVerifying = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("输入验证码".tr).font(.system(size: 24, weight: .regular)).padding(.top, 40)
            
            Text("验证码已发送至 +86 \(phoneNumber)".tr).font(.system(size: 14)).foregroundColor(.gray)
            
            HStack {
                TextField("请输入6位验证码".tr, text: $verifyCode)
                    .keyboardType(.numberPad)
                    .font(.system(size: 22, weight: .medium))
                    .onChange(of: verifyCode) { _, newValue in
                        if newValue.count > 6 { verifyCode = String(newValue.prefix(6)) }
                        // 满 6 位自动触发验证
                        if verifyCode.count == 6 { performVerification() }
                    }
                
                Spacer()
                
                if timeRemaining > 0 {
                    Text("\(timeRemaining)s")
                        .font(.system(size: 14)).foregroundColor(.gray)
                } else {
                    Button("重新获取".tr) {
                        timeRemaining = 60
                        startTimer()
                    }
                    .font(.system(size: 14)).foregroundColor(Color(hex: "#576B95"))
                }
            }
            .padding(.vertical, 15)
            .overlay(Divider(), alignment: .bottom)
            
            if isVerifying {
                HStack {
                    Spacer()
                    ProgressView().progressViewStyle(CircularProgressViewStyle(tint: Color(hex: "#07C160"))).padding(.top, 30)
                    Spacer()
                }
            }
            
            Spacer()
        }
        .padding(.horizontal, 24)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button(action: { dismiss() }) { Image(systemName: "chevron.left").foregroundColor(.primary) }
            }
        }
        .onAppear {
            startTimer()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                UINotificationFeedbackGenerator().notificationOccurred(.success)
            }
        }
        .onDisappear { timer?.invalidate() }
    }
    
    private func startTimer() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            if timeRemaining > 0 { timeRemaining -= 1 } else { timer?.invalidate() }
        }
    }
    
    private func performVerification() {
        isVerifying = true
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            isVerifying = false
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = true }
        }
    }
}

// MARK: - 5. 完整的微信主界面 (修复 Tab 切页时导航栏异常动画问题)
struct WeChatMainView: View {
    @Binding var show: Bool
    @Binding var isLoggedIn: Bool
    @StateObject private var viewModel = WeChatViewModel()
    @ObservedObject var appearance = SystemAppearance.shared 
    
    @State private var selectedTab = 0
    @State private var showActionSheet = false
    
    var body: some View {
        // 🌟 将 TabView 放在最外侧，让每个子页面有独立的 NavigationStack
        TabView(selection: $selectedTab) {
            
            // 1. 微信页
            NavigationStack {
                WeChatChatListView(viewModel: viewModel)
                    .navigationTitle("微信".tr)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(action: { showActionSheet = true }) {
                                Image(systemName: "plus.circle")
                                    .foregroundColor(.primary)
                            }
                        }
                    }
            }
            .tabItem { 
                Image(systemName: selectedTab == 0 ? "message.fill" : "message")
                Text("微信".tr) 
            }
            .tag(0)
            
            // 2. 通讯录页
            NavigationStack {
                WeChatContactsView()
                    .navigationTitle("通讯录".tr)
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarTrailing) {
                            Button(action: { showActionSheet = true }) {
                                Image(systemName: "person.badge.plus")
                                    .foregroundColor(.primary)
                            }
                        }
                    }
            }
            .tabItem { 
                Image(systemName: selectedTab == 1 ? "person.2.fill" : "person.2")
                Text("通讯录".tr) 
            }
            .tag(1)
            
            // 3. 发现页
            NavigationStack {
                WeChatDiscoverView()
                    .navigationTitle("发现".tr)
                    .navigationBarTitleDisplayMode(.inline)
            }
            .tabItem { 
                Image(systemName: selectedTab == 2 ? "safari.fill" : "safari")
                Text("发现".tr) 
            }
            .tag(2)
            
            // 4. 我
            NavigationStack {
                WeChatMeView(isLoggedIn: $isLoggedIn)
                    .navigationTitle("")
                    .navigationBarTitleDisplayMode(.inline)
            }
            .tabItem { 
                Image(systemName: selectedTab == 3 ? "person.fill" : "person")
                Text("我".tr) 
            }
            .tag(3)
            
        }
        .tint(Color(hex: "#07C160"))
        .background(Color(UIColor.systemBackground))
        .confirmationDialog("操作".tr, isPresented: $showActionSheet) {
            Button("发起群聊".tr) { }
            Button("添加朋友".tr) { }
            Button("扫一扫".tr) { }
            Button("收付款".tr) { }
            Button("取消".tr, role: .cancel) { }
        }
    }
}

// MARK: - 6. 微信通讯录 (高度还原布局)
struct WeChatContactsView: View {
    let contacts = ["阿尼亚", "陈晨", "马化腾", "张小龙", "张三", "李四", "王五"]
    
    var body: some View {
        List {
            // 系统功能区
            Section {
                contactRow(icon: "person.badge.plus.fill", color: .orange, title: "新的朋友".tr)
                contactRow(icon: "person.3.fill", color: .green, title: "群聊".tr)
                contactRow(icon: "tag.fill", color: .blue, title: "标签".tr)
                contactRow(icon: "person.crop.square.fill", color: .blue, title: "公众号".tr)
            }
            
            // 假装按字母排序的联系人
            Section(header: Text("A")) { contactCell(name: "阿尼亚") }
            Section(header: Text("C")) { contactCell(name: "陈晨") }
            Section(header: Text("M")) { contactCell(name: "马化腾") }
            Section(header: Text("Z")) {
                contactCell(name: "张小龙")
                contactCell(name: "张三")
            }
            
            Text("\(contacts.count) 位联系人".tr)
                .frame(maxWidth: .infinity, alignment: .center)
                .font(.system(size: 14))
                .foregroundColor(.secondary)
                .listRowBackground(Color.clear)
                .listRowSeparator(.hidden)
        }
        .listStyle(.plain)
    }
    
    private func contactRow(icon: String, color: Color, title: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundColor(.white).frame(width: 40, height: 40)
                .background(color).cornerRadius(4)
            Text(title).font(.system(size: 16))
        }
        .padding(.vertical, 4)
    }
    
    private func contactCell(name: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "person.fill")
                .foregroundColor(.gray.opacity(0.8)).frame(width: 40, height: 40)
                .background(Color(UIColor.secondarySystemFill)).cornerRadius(4)
            Text(name).font(.system(size: 16))
        }
        .padding(.vertical, 4)
    }
}

// MARK: - 7. 微信“我” (还原真实的图标与布局)
struct WeChatMeView: View {
    @Binding var isLoggedIn: Bool
    
    var body: some View {
        List {
            Section {
                HStack(spacing: 16) {
                    Image(systemName: "person.crop.square.fill")
                        .resizable().frame(width: 64, height: 64)
                        .foregroundColor(.gray.opacity(0.5)).cornerRadius(8)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("幼".tr).font(.system(size: 20, weight: .semibold))
                        HStack {
                            Text("微信号：kunoouc".tr).font(.system(size: 14)).foregroundColor(.secondary)
                            Spacer()
                            Image(systemName: "qrcode").foregroundColor(.secondary)
                            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
                        }
                    }
                }
                .padding(.vertical, 14)
            }
            
            Section {
                settingRow(icon: "creditcard.fill", color: Color(hex: "#07C160"), title: "服务".tr)
            }
            
            Section {
                settingRow(icon: "cube.box.fill", color: .yellow, title: "收藏".tr)
                settingRow(icon: "photo.fill", color: .blue, title: "朋友圈".tr)
                settingRow(icon: "lanyardcard.fill", color: .blue, title: "卡包".tr)
                settingRow(icon: "face.smiling.fill", color: .orange, title: "表情".tr)
            }
            
            Section {
                settingRow(icon: "gearshape.fill", color: .blue, title: "设置".tr)
            }
            
            // 为了调试演示方便，登出按钮单独放在最下面
            Section {
                Button(action: {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                    withAnimation(.easeInOut(duration: 0.3)) { isLoggedIn = false }
                }) {
                    Text("退出登录".tr).font(.system(size: 16)).foregroundColor(.red).frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
        .listStyle(.insetGrouped)
    }
    
    private func settingRow(icon: String, color: Color, title: String) -> some View {
        HStack {
            Image(systemName: icon).foregroundColor(color).frame(width: 24, height: 24)
            Text(title).font(.system(size: 16))
            Spacer()
            Image(systemName: "chevron.right").font(.caption).foregroundColor(.gray)
        }
        .padding(.vertical, 2)
    }
}
